package com.cj.pc;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ P_Live_001.class, P_Live_002.class, P_Live_003.class, P_Live_004.class, P_Live_005.class,
		P_Live_006.class, P_Live_007.class, P_Live_008.class, P_Live_009.class, P_Live_010.class, P_Live_011.class,
		P_Live_012.class, P_Live_013.class, P_Live_014.class, P_Live_015.class, P_Live_016.class, P_Live_017.class,
		P_Live_018.class, P_Live_019.class, P_Live_020.class })
public class AllTests {

}
