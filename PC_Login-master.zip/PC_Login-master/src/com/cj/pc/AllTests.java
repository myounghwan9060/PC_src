package com.cj.pc;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ P_001.class, P_002.class, P_003.class,
		P_004.class, P_005.class, P_006.class, P_007.class, P_008.class, P_009.class, P_010.class, P_011.class,
		P_012.class, P_013.class, P_014.class, P_015.class, P_016.class, P_017.class, P_018.class, P_019.class,
		P_020.class, P_021.class, P_022.class, P_023.class, P_024.class, P_025.class, P_026.class, P_027.class,
		P_028.class, P_029.class, P_030.class, P_031.class, P_032.class, P_033.class, P_034.class, P_035.class,
		P_036.class, P_037.class, P_038.class, P_039.class, P_040.class, P_041.class, P_042.class, P_043.class,
		P_044.class, P_045.class, P_046.class, P_047.class, P_048.class, P_049.class, P_050.class, P_051.class,
		P_052.class, P_053.class, P_054.class, P_055.class, P_056.class, P_057.class, P_058.class, P_059.class,
		P_060.class, P_061.class, P_062.class, P_063.class, P_064.class, P_065.class, P_066.class, P_067.class,
		P_068.class, P_070.class, P_071.class, P_072.class, P_073.class, P_074.class, P_075.class, P_076.class,
		P_077.class, P_078.class})
public class AllTests {

}
